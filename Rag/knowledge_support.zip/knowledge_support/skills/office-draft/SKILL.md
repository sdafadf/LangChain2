---
name: office-draft
description: 将校园办公原文整理为会议纪要、待办候选或通知草稿，供人工核对后导出。
---

调用 `CampusCoordinator.office(kind, text)`；kind 为会议纪要与待办或通知草稿，text 为 1 至 20000 字。离线原文规则提取不判断提议是否已通过。缺少负责人、时间、对象时标记待确认。

返回 answer、sources、trace。结果不自动发布，不宣称已完成办公操作。使用 `campus_core.redact` 进行部分身份脱敏后供用户编辑预览；人工确认学校信息与个人身份后再下载。该脱敏函数不能自动识别全部姓名和学校标识。
