---
name: teaching-design
description: 将已核对的校园学情汇总转成教学建议、课堂练习和课程内容改进草稿。
---

输入为 learning-analysis 产生的 report 和教师目标。离线用 `campus_core.teaching_plan(report)` 返回标明规则生成的建议；生成式任务用 `CampusCoordinator.teaching(report, objective)`，需要可用 ModelConfig。

输出 answer、sources、trace。教学设计是建议，练习答案需教师复核；没有检索课程资料时，不称练习有知识库依据。模型失败显示未完成，不自动转云端。通过 `generate` 统一遵守本地地址约束和云端文本发送确认。
