---
name: learning-analysis
description: 分析匿名成绩 CSV，计算校园班级得分率与薄弱知识点，供教师审核与教学设计使用。
---

使用项目根目录 `campus_core.parse_grades(bytes, allow_duplicates=False)` 校验输入，再调用 `CampusCoordinator.analysis(rows, threshold)`。输入列严格为学生编号、知识点、得分、满分；重复学生知识点组合由使用者明确选择保留全部才接受。

输出包含 report、answer、sources、trace；report 为确定性统计，answer 为本地规则建议。比率采用得分总和除以满分总和，不称为学生平均掌握率。原始学生记录不传递给模型；下游 teaching-design 只接收汇总结果。异常整批拒绝并提示修正，不静默删除成绩。用 `python -m unittest test_campus.BusinessTests` 验证计算和导入边界。
